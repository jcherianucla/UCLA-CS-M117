//
//  MessageProtocols.swift
//  MemCap
//
//  Created by Jahan Cherian on 5/22/16.
//  Copyright © 2016 Jahan Cherian. All rights reserved.
//

import Foundation

protocol messageProtocol
{
    func cancelButtonPressed()
    func sendButtonPressed()
}
