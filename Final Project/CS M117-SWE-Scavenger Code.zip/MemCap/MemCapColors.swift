//
//  MemCapColors.swift
//  MemCap
//
//  Created by Jahan Cherian on 5/19/16.
//  Copyright © 2016 Jahan Cherian. All rights reserved.
//

import Foundation
import UIKit

class MemCapColors
{
    //Change this color pl0x
    static func MemCapOrange(alpha: CGFloat = 1.0) -> UIColor {
        return UIColor(red: 0.29, green: 0.79, blue: 0.82, alpha: alpha)
    }

}
